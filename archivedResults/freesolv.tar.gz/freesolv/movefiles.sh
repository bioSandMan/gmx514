#! /bin/bash


declare -a files=('mobley_1929982'
'mobley_5631798'
'mobley_9055303'
'mobley_1636752'
'mobley_2008055'
'mobley_4364398'
'mobley_525934'
'mobley_6714389'
'mobley_7261305'
'mobley_9029594'
'mobley_1107178'
'mobley_1800170'
'mobley_2068538'
'mobley_2146331'
'mobley_2310185'
'mobley_2410897'
'mobley_4434915'
'mobley_5692472'
'mobley_6091882'
'mobley_7015518'
'mobley_8983100'
'mobley_9073553');


## now loop through the above array
for i in "${files[@]}"
do
    cp /Users/ChrisM/Downloads/FreeSolv-0.51/gromacs_solvated/$i.* solvated/.
done

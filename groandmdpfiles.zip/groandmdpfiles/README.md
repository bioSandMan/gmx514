This folder contains example GROMACS files to reproduce the results from the paper. The only thing needed to be changed are the lambda values for each of the different simulations.


#!/bin/bash
workingDir=$PWD
for i in {1..8}; do
  cd $workingDir/run0$i
  skip=`tail -n -1 prod.0.dhdl.xvg | awk '{ print $1/2 }'`
  echo $PWD
  echo $skip
  #/mnt/ceph/cmira/alchemical-analysis/alchemical_analysis/alchemical_analysis.py -t 300 -x -s $skip -i 0 -p prod >> alchem.log
done
